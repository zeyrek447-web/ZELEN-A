
ZELENIA Starter Site
===================

- Dark theme AI crypto signal demo for Solana.
- Phantom wallet placeholder included.
- Token signals and dashboard placeholders included.
- Can deploy directly on Vercel or Netlify.
